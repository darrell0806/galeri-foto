<div id="main-content">
	<div class="page-heading">
		<div class="page-title">
			<div class="row justify-content-center">
				<img src="<?=base_url('prixier/img/logo_sph.png')?>" alt="logo" style="max-width: 10%; height: auto; margin-top: 50px; margin-bottom: 15px;">
			</div>
			<div class="col-12 col-md-6 order-md-2 order-first">
				<nav aria-label="breadcrumb" class="breadcrumb-header float-start float-lg-end">
					<ol class="breadcrumb">

					</ol>
				</nav>
			</div>
		</div>
	</div>

	<section class="section">
		<div class="container">
			<div class="row justify-content-center">
				<p class="text-center">Silahkan Login dengan mengklik tombol di bawah dengan mengisi <strong>NIK</strong> dan <strong>PASSWORD</strong> yang telah dibuat sebelumnya.</p>
			</div>
			<div class="d-flex justify-content-center">
				<a href="<?=base_url('login_pendaftaran')?>" class="btn btn-primary">Login Disini</a>
			</div>
		</div>
	</section>
</div>
